# Roteiro de fala — Mundo Mental Care (ZelluApp)

Apresentação do **núcleo ZelluApp** (Dashitecnology), na adaptação white-label **Mundo Mental Care** — primeiro cliente: **Mundo Mental**.  
Duração alvo: **10–15 minutos**.

**Como usar:** cada bloco abaixo corresponde a um slide. Leia o texto em voz alta; o que está em *itálico* são lembretes para você (não ler).

**Navegação no deck:** setas `←` `→` · `T` tema · `F` tela cheia

---

## Slide 1 — Capa
*Título na tela: Mundo Mental Care · eyebrow ZelluApp / Dashitecnology / primeiro cliente white-label*

Bom dia / boa tarde.

Obrigado pelo tempo. Vou apresentar o **Mundo Mental Care**.

Antes de entrar no produto: esta aplicação foi criada pela **Dashitecnology**, faz parte do núcleo **ZelluApp**, e está **adaptada para a Mundo Mental** no formato Mundo Mental Care. Ou seja: já estamos aplicando um modelo **white-label** — e a Mundo Mental é o **primeiro cliente** neste formato.

O que vocês veem na tela é a marca e a experiência do cliente; por baixo, é a plataforma ZelluApp.

Tagline desta adaptação: *cuidado emocional no ritmo do trabalho*.

---

## Slide 2 — Agenda
*Título na tela: O que vamos percorrer*

Em cerca de quinze minutos, quatro partes.

Primeiro, o **contexto**: o problema corporativo de bem-estar no dia a dia.

Segundo, o **produto**: companion, RH e operação — como o colaborador e a empresa usam a plataforma.

Terceiro, a **tecnologia**: o núcleo ZelluApp, IA com consentimento e privacidade.

Por fim, o **white-label**: como a Dashitecnology adapta esse núcleo para clientes — começando pela Mundo Mental.

Sem métricas de tração nesta versão: o foco é o produto e o fato de o white-label **já estar em aplicação**.

---

## Slide 3 — Problema
*Título na tela: Empresas investem em saúde mental — e o hábito some entre as sessões*

O cenário é conhecido: a empresa contrata saúde mental, faz campanhas, às vezes oferece sessões — e entre um contato e outro o **hábito some**.

Três dores se repetem.

**Baixa adesão:** o programa existe, mas o colaborador não mantém um contato leve e frequente.

**RH sem visão útil:** quem cuida de pessoas precisa de sinais de tendência por equipe, sem invadir a privacidade individual.

**Gap entre clínica e rotina:** o cuidado não acompanha a pressão do trabalho no dia a dia.

Importante: este produto **não substitui** psicólogo, psiquiatra ou terapia. É companion de bem-estar e autocuidado — e isso vale tanto no núcleo ZelluApp quanto nesta adaptação Mundo Mental Care.

---

## Slide 4 — Solução
*Título na tela: Uma plataforma SaaS B2B de companion emocional*

A resposta é uma **plataforma SaaS B2B** completa, no núcleo **ZelluApp**, da **Dashitecnology**.

Nesta versão, marca e experiência estão adaptadas para a **Mundo Mental** como **Mundo Mental Care** — nosso primeiro cliente white-label.

Para o colaborador: uso diário — check-ins, conversa com companion, hábitos, plano de cuidado.

Para o RH: indicadores **agregados e anônimos**.

Para quem opera: portal administrativo de empresas, licenças e convites.

IA na nuvem só com **consentimento explícito**.

Em uma frase: o núcleo é ZelluApp; o que vocês veem aqui é a pele white-label da Mundo Mental.

---

## Slide 5 — Três níveis
*Título na tela: Três níveis, um só núcleo · diagrama Mermaid*

Este diagrama é a arquitetura do **núcleo ZelluApp** — e é a mesma estrutura que o white-label Mundo Mental Care opera.

No topo, o **operador do white-label** usa o Portal Admin: empresas, licenças e uso.

Dentro da empresa cliente final: o **Painel RH**, com agregados, e o **Companion**, usado pelo colaborador.

O admin configura o acesso e emite convites. O RH vê só **indicadores anônimos** — nunca chat, diário ou humor identificado.

Três papéis, um núcleo. Isso é o que permite white-label de verdade — e não só troca de logo.

---

## Slide 6 — Jornada
*Título na tela: Do check-in ao cuidado — em minutos · diagrama Mermaid*

Jornada do colaborador, nesta adaptação Mundo Mental Care.

Começa com o **check-in**: sono, água, humor.

Isso alimenta o **companion**: conversa já contextualizada.

Quando faz sentido, uma **ação leve**: respiro, pausa, movimento.

Depois, **hábitos** e **plano de cuidado**, e o acompanhamento no **dashboard emocional**.

Minutos na rotina de trabalho — não uma sessão longa. Check-in, chat, respiro e diário são os pilares mais visíveis.

---

## Slide 7 — Companion
*Título na tela: O que o companion entrega no dia a dia*

No módulo do colaborador, três entregas.

**Conversa:** apoio emocional cotidiano, tom maduro, sem fingir ser terapia. Sugestões práticas — respirar, água, pausa.

**Contexto:** check-ins, hábitos, plano e memórias curadas. Sem inventar dados. **Texto do diário não vai para a IA.**

**Prevenção:** alertas de tendência para a própria pessoa; em crise, prioridade para ajuda humana — por exemplo, CVV 188.

Por baixo: check-in, chat, diário, hábitos, plano, respiro, dashboard e insights — tudo do núcleo ZelluApp, com a identidade Mundo Mental Care.

---

## Slide 8 — IA e memória
*Título na tela: IA sob consentimento — com fallback local · diagrama Mermaid*

Como a inteligência funciona no núcleo — e nesta adaptação.

Se há **risco imediato**, não é conversa casual: resposta de crise e orientação a ajuda profissional.

Sem crise, o sistema verifica o **opt-in de IA**. Com consentimento, a mensagem vai ao modelo via OpenRouter — com contexto de bem-estar, **sem nome, e-mail ou diário**.

Sem opt-in: **fallback local**, ainda contextual, sem enviar dados a modelo externo.

**Memórias curadas:** resumos curtos do que ajuda — com limite e sem conteúdo de crise. No perfil: três escolhas — IA, RH e e-mail.

Para quem licencia o núcleo ou opera o white-label: narrativa de **IA responsável** já embutida.

---

## Slide 9 — RH
*Título na tela: Visibilidade ética para a empresa · diagrama Mermaid*

O painel de RH resolve a tensão: a empresa quer enxergar; a pessoa quer privacidade.

O RH **vê**: indicadores agregados, adesão, tendências — com opt-in suficiente.

O RH **nunca vê**: diário, chat, humor/sono/água identificados.

Colaboradores com opt-in entram numa **agregação com mínimo de cinco pessoas**. Abaixo disso, métricas sensíveis ficam ocultas.

Isso é regra do núcleo ZelluApp — e vale na operação Mundo Mental Care.

---

## Slide 10 — Licenciamento / white-label
*Título na tela: Núcleo licenciável — com white-label já em produção · diagrama Mermaid*

Aqui está o posicionamento correto.

A tecnologia é da **Dashitecnology**. O produto de plataforma é o núcleo **ZelluApp**. O **white-label** adapta marca e experiência para cada cliente.

O **Mundo Mental Care** é essa adaptação para a **Mundo Mental** — nosso **primeiro cliente** neste modelo.

O pacote do núcleo inclui: companion; painel RH; portal admin; camada de IA; base LGPD.

No diagrama: Dashitecnology → ZelluApp → white-label → Mundo Mental Care → Mundo Mental → empresas usuárias → colaboradores.

Não é só “pronto para white-label”. **Já está em aplicação**, com a Mundo Mental como primeiro caso.

---

## Slide 11 — Diferenciais
*Título na tela: Diferenciais do núcleo ZelluApp*

Por que este núcleo?

**Produto fechado:** colaborador + RH + admin — não só chatbot.

**Privacidade de produto:** opt-ins, isolamento, k-anonimato, diário fora do prompt.

**Operação B2B:** multi-empresa, licenças, convites, papéis.

**Tom cuidadoso:** companion de bem-estar, com limites claros.

**IA responsável:** opt-in, fallback local, crise no servidor.

**White-label comprovado:** já adaptado para a Mundo Mental como Mundo Mental Care.

---

## Slide 12 — LGPD
*Título na tela: Privacidade como parte do produto*

Em saúde mental corporativa, compliance é diferencial — no núcleo e no white-label.

O titular controla consentimento, maioridade, opt-ins; pode exportar, excluir e revogar.

A plataforma: retenção limitada, memórias com limpeza, logs sem dado de saúde desnecessário; IA com pedido de não retenção e sem treino no provedor, quando autorizada.

Para a Dashitecnology e para o cliente white-label, isso reduz risco e acelera a conversa com jurídico e DPO.

---

## Slide 13 — Fechamento
*Título na tela: Núcleo pronto — white-label em andamento*

Para fechar.

Tecnologia da **Dashitecnology**, núcleo **ZelluApp**, adaptada para a **Mundo Mental** como **Mundo Mental Care** — primeiro cliente white-label.

O próximo passo natural é alinharmos o **modelo de licenciamento** do núcleo e, se fizer sentido, uma demonstração guiada nesta adaptação.

Obrigado. Fico à vontade para perguntas.

---

## Tempo sugerido por slide

| Slide | Minutos (aprox.) |
|------:|-----------------:|
| 1 Capa | 0,5–1 |
| 2 Agenda | 0,5 |
| 3 Problema | 1,5 |
| 4 Solução | 1,5 |
| 5 Três níveis | 1,5 |
| 6 Jornada | 1 |
| 7 Companion | 1,5 |
| 8 IA | 1,5–2 |
| 9 RH | 1 |
| 10 Licenciamento / WL | 1,5–2 |
| 11 Diferenciais | 1 |
| 12 LGPD | 1 |
| 13 Fechamento | 0,5–1 |
| **Total** | **≈ 13–15 min** |

*Se precisar enxugar para 10 min: encurte os slides 7, 8 e 11.*
